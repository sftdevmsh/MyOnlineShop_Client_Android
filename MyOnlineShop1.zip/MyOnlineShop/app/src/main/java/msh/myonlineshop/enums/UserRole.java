package msh.myonlineshop.enums;

public enum UserRole {
    ADMIN,
    USER
}
