package msh.myonlineshop.models;

import java.io.Serializable;

public class Customer implements Serializable
{}
