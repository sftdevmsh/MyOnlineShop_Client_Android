//package msh.myonlineshop.clients;
//
//import retrofit2.Call;
//import retrofit2.http.GET;
//
//public interface ContentClient {
//    @GET("content/getAllData")
//    Call<ServiceResponse<Content>> getAll();
//}
