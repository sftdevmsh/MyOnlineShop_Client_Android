package msh.myonlineshop.enums;

public enum ServiceStatus {
    SUCCESS,
    FAILED,
    EXCEPTION
}
